/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author anyel
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.spi.DirStateFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    //Información de conexión
    
   //private static final String SERVIDOR = "DESKTOP-PV3BIL6";
    //private static final String SERVIDOR = "192.168.131.136";

    private static final String SERVIDOR = "192.168.131.136";
    private static final String BASE_DATOS = "Mariscos";
    private static final String USUARIO = "sa";
    private static final String CONTRASENA = "AnyelBSC@2002*+";

    // URL de conexión sin encriptación
    private static final String URL = "jdbc:sqlserver://" + SERVIDOR + ":1433;database=" + BASE_DATOS +
        ";user=" + USUARIO + ";password=" + CONTRASENA + ";loginTimeout=30;" +
        "encrypt=true;trustServerCertificate=true;";

    
    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL);
        } catch (SQLException e) {
            //e.printStackTrace();
            JOptionPane.showMessageDialog(null, e);

            return null;
        }
    }
    
    public static Statement getStatement() {
        try {
            Connection cn = getConnection();
            if (cn != null) {
                return cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            } else {
                return null;
            }
        } catch (SQLException e) {
            //e.printStackTrace();
                        JOptionPane.showMessageDialog(null, e);

            return null;
        }
    }
    
    public static void main(String[] args) {
        try (Connection cn = getConnection()) {
            System.out.println("¡Conexión exitosa!");
        } catch (SQLException e) {
            System.out.println("No se pudo establecer la conexión.");
            e.printStackTrace();
        }
    }
    
}


