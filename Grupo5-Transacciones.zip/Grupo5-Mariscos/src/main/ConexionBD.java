/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class ConexionBD {
    
   /* private static final String SERVIDOR = "DESKTOP-PV3BIL6"; //WINDOWS 
    //private static final String SERVIDOR = "192.168.131.132"; // LINUX

    private static final String BASE_DATOS = "Mariscos";
    private static final String usuario = "angel";
    private static final String contrasena = "angel";
    public Connection getConnection() {
        // URL de conexión
        String URL = "jdbc:sqlserver://" + SERVIDOR + ":1433;database=" + BASE_DATOS +
                     ";user=" + usuario + ";password=" + contrasena + ";loginTimeout=30;";

        try {
            return DriverManager.getConnection(URL);
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error, no se pudo acceder");
            return null;
        }
    }

    public Statement getStatement() {
        try {
            Connection cn = getConnection();
            if (cn != null) {
                return cn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            } else {
                return null;
            }
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Upps!!... Error");
            return null;
        }
    }
   // Constructor para recibir usuario y contraseña
    /*public ConexionBD(String usuario, String contrasena) {
        this.usuario = usuario;
        this.contrasena = contrasena;
    }*/
    
    /*public void mostrarDatos() {
        System.out.println("Usuario: " + usuario);
        System.out.println("Contraseña: " + contrasena);
    }*/
}
